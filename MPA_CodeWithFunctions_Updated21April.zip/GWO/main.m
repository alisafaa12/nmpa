%___________________________________________________________________%
%  Grey Wold Optimizer (GWO) source codes version 1.0               %
%                                                                   %
%  Developed in MATLAB R2011b(7.13)                                 %
%                                                                   %
%  Author and programmer: Seyedali Mirjalili                        %
%                                                                   %
%         e-Mail: ali.mirjalili@gmail.com                           %
%                 seyedali.mirjalili@griffithuni.edu.au             %
%                                                                   %
%       Homepage: http://www.alimirjalili.com                       %
%                                                                   %
%   Main paper: S. Mirjalili, S. M. Mirjalili, A. Lewis             %
%               Grey Wolf Optimizer, Advances in Engineering        %
%               Software , in press,                                %
%               DOI: 10.1016/j.advengsoft.2013.12.007               %
%                                                                   %
%___________________________________________________________________%

% You can simply define your cost in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @YourCostFunction
% dim = number of your variables
% Max_iteration = maximum number of generations
% SearchAgents_no = number of search agents
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single number numbers

% To run GWO: [Best_score,Best_pos,GWO_cg_curve]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj)
%__________________________________________

clear;close all;
clc
addpath('ica')
% addpath('mica')
addpath('GSA')
addpath('OICA')
addpath('DE')
addpath('Harmony Search')
addpath('GA (Real)')
addpath('Artificial Bee Colony')

SearchAgents_no = 100; % Number of search agents
str = '%s%d';
A1 = 'F';
b = 1;
for i= 23:23
    A2 = i;
    Function_name=sprintf(str,A1,A2); % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)

    Max_iteration = 500; % Maximum numbef of iterations

% Load details of the selected benchmark function
    [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
%     dim=30;
% lb = -150;
% ub = 150;
     for ii=1:30
%         [Best_score(1,ii),Best_pos,GWO_cg_curve]= GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);

%         [BEST,BESTSol(1,ii)]= GSA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);

%         [Best_score2(1,ii),Best_pos2,GWO_cg_curve2]= ICGWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
%         [Best_score3(1,ii),Best_pos3,GWO_cg_curve3]= CDGWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
%         [Best_score3(1,ii)]= hs(Max_iteration,lb,ub,dim,fobj);

%         [Best_score4(1,ii),Best_pos4,GWO_cg_curve4]= CGWO1(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);

%         [Best_score5(1,ii)]= abc(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);

%          [BestCost,BestSol(1,ii)] = de(fobj,dim,SearchAgents_no,Max_iteration,lb,ub);
% 
%          [gBestCost1,gBest(1,ii)] = original_ica(fobj,dim,SearchAgents_no,Max_iteration,lb,ub);
%         [~,mgBestSol1] = MGICA(fobj,dim,SearchAgents_no,Max_iteration,lb,ub);
%          [gBestCost,gBestSol(1,ii)] = GWICA(fobj,dim,SearchAgents_no,Max_iteration,lb,ub);
%          [gBestCost1,gBestSol1(1,ii)] = CGWICA(fobj,dim,SearchAgents_no,Max_iteration,lb,ub);
        
% 
%          [bestcost(1,ii),cg_curve]=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); % run PSO to compare to results
    end
%     
% [ps,hs,ss]=ranksum(Best_score2(1,ii),Best_score(1,ii));
% [ps1,hs1,ss1]=ranksum(Best_score2(1,ii),BEST(1,ii));
% [ps2,hs2,ss2]=ranksum(Best_score2(1,ii),Best_score3(1,ii));
% [ps3,hs3,ss3]=ranksum(Best_score2(1,ii),BestCost(1,ii));
% [ps4,hs4,ss4]=ranksum(Best_score2(1,ii),gBestCost1(1,ii));
% [ps5,hs5,ss5]=ranksum(Best_score2(1,ii),PSO_cg_curve(1,ii));

% fmean=mean(gBestCost1);
%     fmean1=mean(gBestSol);
%     disp([ ' F'  num2str(i)   ': BEST Solution of GWICA = '  num2str(fmean1)]);
%     disp([ ' F'  num2str(i)   ': BEST Solution of ICAORGINAL = '  num2str(fmean)]);
% figure('Position',[500 500 660 290])
% %Draw search space
% subplot(1,2,1);
% func_plot(Function_name);
% title('Parameter space')
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Function_name,'( x_1 , x_2 )'])
% 
% %Draw objective space
% subplot(1,2,2);
% figure;
% semilogy(GWO_cg_curve,'Color','r','LineWidth',1.5)
% hold on
% % semilogy(BEST,'Color',[0.85 0.0 0.65],'LineWidth',1.5)
% % hold on
% semilogy(GWO_cg_curve2,'Color','b','LineWidth',1.5)
% hold on
% semilogy(GWO_cg_curve3,'Color','k','LineWidth',1.5)
% hold on
% % semilogy(gBestCost,'Color','y','LineWidth',1.5)
% % hold on
% % semilogy(BestCost,'Color','g','LineWidth',1.5)
% % hold on
% % semilogy(cg_curve,'Color',[0.6000    0.0000         0],'LineWidth',1.5)
% % hold off
% % semilogy(BestCost,'Color',[0.5000         0    1.0000],'LineWidth',2.5)
% % hold on
% % semilogy(gBestCost1,'Color',[0.6    1.0000    1.0000],'LineWidth',2.5)
% % semilogy(mgBestCost1,'Color',[0.8    1.0000    1.0000],'LineWidth',2.5)
% title(Function_name)
% xlabel('Iteration');
% ylabel('Best score obtained so far');
% % % 
% axis tight
% grid on
% box on
% legend('GWO','ICGWO','CDGWO')
% % legend('GSA','ICA','GWICA','DE','PSO')
% % legend('GWO','GA','CGWO','HS','CGWO1','abc','PSO','DE','ICA')
% 
% % display(['The best solution obtained by GWO is : ', num2str(Best_pos)]);
% % display(['The best optimal value of the objective funciton found by GWO is : ', num2str(Best_score)]);
% GWO_Min = min(Best_score);
DE_Std = std(bestcost);
DE_Avg = mean(bestcost);

% CGWO_Min = min(Best_score2);
% CGWO_Std = std(Best_score2);
% CGWO_Avg = mean(Best_score2);
%  
% CDGWO_Min = min(Best_score3);
% CDGWO_Std = std(Best_score3);
% CDGWO_Avg = mean(Best_score3);
%  
% hs_Min = min(Best_score3);
% hs_Std = std(Best_score3);
% hs_Avg = mean(Best_score3);
 
% CGWO1_Min = min(Best_score4);
% CGWO1_Std = std(Best_score4);
% CGWO1_Avg = mean(Best_score4);
%  
% abc_Min = min(Best_score5);
% abc_Std = std(Best_score5);
% abc_Avg = mean(Best_score5);
%  
% de_Min = min(BestCost);
% de_Std = std(BestCost);
% de_Avg = mean(BestCost);
%         
% original_ica_Min = min(gBestCost1);
% original_ica_Std = std(gBestCost1);
% original_ica_Avg = mean(gBestCost1);
% 
% PSO_Min = min(PSO_cg_curve);
% PSO_Std = std(PSO_cg_curve);
% PSO_Avg = mean(PSO_cg_curve);



%% Saving Results
% T = table(GWO_Min,GWO_Std,GWO_Avg,CGWO_Min,CGWO_Std,CGWO_Avg,...
%           hs_Min,hs_Std,hs_Avg,CGWO1_Min,...
%           CGWO1_Std,CGWO1_Avg,abc_Min,abc_Std,abc_Avg,de_Min,...
%           de_Std,de_Avg,original_ica_Min,original_ica_Std,original_ica_Avg,...
%           PSO_Min,PSO_Std,PSO_Avg);
% T = table(GSA_Min,GSA_Std,GSA_Avg) ;         
% % T(:,1:24);
% T (:,1:3);
% Filename = 'Function23.xlsx';
% if i == 1
%  b = 1;
% else
%     b = b+3;
% end
% str1 = '%s%d';
% a = 'A';
% c =sprintf(str1,a,b);
% writetable(T,Filename,'sheet',1)

end
